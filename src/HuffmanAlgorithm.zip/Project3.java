import java.io.*;

public class Project3 {

	public static void main(String[] args) throws Exception {
		
	
		File file = new File("randTest.txt");
		
		
		HuffmanEncoder myHuff = new HuffmanEncoder();
		String result = myHuff.getFrequencies(file);
		System.out.println(result);
		
		HuffTree myTree= new HuffTree(file);
		
		String returnString;
		try {
			System.out.println("The codes are: ");
			returnString = myHuff.traverseHuffmanTree(myTree);
			System.out.println(returnString);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("The file code is:");
		String fileCode = myHuff.encodeFile(file, myTree);
		System.out.println(fileCode);
		
		
		
		String correct = "0110110000101101111111100111010100000100110000000111100111111"
				+ "111011011001100101111010110010110100110000001100100010110111000"
				+ "1000011000011010001001000011000010110100101101001101111011001101"
				+ "11010000100000111011111000011101001100010001001111101110101111010"
				+ "01101100111111011010101010001000101100010011010001100100101011001010"
				+ "0011111100001001000100000111101011011010100011101100"
				+ "000100100101000100110110100110011011101111110010110001111001011"
				+ "01111111101000000110111011100100011001010101010010001010111001111";
		if (fileCode.equals(correct)) {
			System.out.println("you got it correct.");
		}
		
		System.out.println("The decoded text is: ");
		String decoded = myHuff.decodeFile(correct, myTree);
		String correctDecoded = "=a=az=a=aaaaaaaQaa==wQa_aaaaQaaaaaaaa=a=aQaQ=aaa==aQ=a=QaGaQ1=a=aa1zaza=1Qzaz=a=Q=a=Qa=aaa=aQa=aa=zwaa=aaaazaa=Qa11Qaaaa=aa==aaa=Qa=aQaaaaa=a====11=a1Qa=1aQQ==aQ=1aaaaazQ1waaa==a=a==1aa=awQQ=1Qa=a=QaQa=aa=aaaaaQ=a1aaaQ=a=aaaaaaa=Ga=aa=aaQ1aQ====Q1==aaQaaa";
		System.out.println(decoded);
		if (decoded.equals(correctDecoded)) {
			System.out.println("You got it right again!");
		}
		
	}

}
